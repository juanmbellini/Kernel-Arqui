#include <types.h>
#include <stdint.h>
 
void turnOnSound(uint64_t frequency);
void turnOffSound(void);

