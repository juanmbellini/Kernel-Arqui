#include <types.h>
#include <stdint.h>
#define STDIN 0
#define STDOUT 1
#define SPK 2
#define TIMER 3
#define CLEAR 3


void read(uint64_t fileDescriptor, uint64_t buffer, uint64_t size, uint64_t aux1, uint64_t aux2);
void write(uint64_t fileDescriptor, uint64_t buffer, uint64_t size, uint64_t aux1, uint64_t aux2);
