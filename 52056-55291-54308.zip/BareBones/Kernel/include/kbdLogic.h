#include <stdint.h>
char getCharFromKbd(void);
uint16_t getNoteFromKbd(void);
uint64_t checkKbdInterrupt(void);
