#include <stdint.h>


void timerISR(void);

uint64_t getTicks(void);

uint64_t getFrequency(void);