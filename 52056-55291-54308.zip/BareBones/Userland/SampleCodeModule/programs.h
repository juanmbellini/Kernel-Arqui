void showHelp(void);
void beep(void);
void piano(void);
void echo(void);
void stopWatch(void);
void playMusic(void);
