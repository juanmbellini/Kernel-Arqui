#include <stdint.h>
#define STDIN 0
#define STDOUT 1
#define SPK 2
#define TIMER 3

void read(uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
void write(uint64_t, uint64_t, uint64_t, uint64_t, uint64_t);
