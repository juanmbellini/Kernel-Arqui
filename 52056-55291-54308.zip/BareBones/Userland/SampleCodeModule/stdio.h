#include <stdint.h>
char getchar(void);
void putchar(char c);
void printf(char * fmt, ...);
void readLine(char * buffer, int size);
uint64_t askIfThereWasInput(void);
void clearShell(void);

