
int strcmp(char * str1, char * str2);
int strsize(char * str);
