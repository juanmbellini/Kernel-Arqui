
int ipow(int base, int exp);
int decimalDigits(int number);
int floor(double number);